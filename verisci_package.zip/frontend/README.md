# VeriSci Frontend (Prototype)

This is a single-file React/Next.js prototype component. Replace mock endpoints with your production API.

File: `VeriSciDashboard.jsx` (component)
