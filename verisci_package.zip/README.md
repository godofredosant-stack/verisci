# VeriSci - Paquete completo (Frontend + Backend)

## Contenido
- Frontend: Prototype React component (frontend/VeriSciDashboard.jsx)
- Backend: FastAPI app in backend/app
- Worker: Celery tasks for processing media and calling external APIs
- PubMed wrapper: backend/app/pubmed.py
- Docker + docker-compose for local deployment

## Instrucciones rápidas (local)

1. Copia `.env.example` a `.env` y añade tus claves:
   - OPENAI_API_KEY
   - CELERY_BROKER_URL (si usas Redis externo)
2. Levanta con Docker Compose:
   ```
   docker-compose up --build
   ```
3. Frontend: integra `frontend/VeriSciDashboard.jsx` en un proyecto Next.js (pages/index.js) o en tu app React.
4. Backend: la API estará disponible en http://localhost:8000
   - Documentación Swagger: http://localhost:8000/docs

## Subir al repositorio GitHub (desde PC)

1. Descomprime el ZIP en tu PC.
2. Abre terminal, navega a la carpeta del proyecto.
3. Inicializa git y sube al repo remoto (reemplaza URL por tu repo):
   ```
   git init
   git add .
   git commit -m "Initial commit: VeriSci full package"
   git branch -M main
   git remote add origin https://github.com/YOUR_USER/verisci.git
   git push -u origin main
   ```

## Subir desde móvil (sin Git)
- En GitHub web (tu repositorio), presiona 'Add file' → 'Upload files' → arrastra/selecciona todos los archivos del ZIP descomprimido desde tu administrador de archivos móvil → Commit.

## Notas
- Este paquete es un punto de partida. Reemplaza las llamadas mock por integración real con OpenAI/Whisper, PubMed, Google Drive y Telegram.
- Para producción recomiendado: Postgres, S3/GCS, Kubernetes y gestión de secretos.
